﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management.Automation;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static API.SESEAP.S1.Operaciones;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace API.SESEAP.S1
{
        public delegate void lanzaDelegado(int contador); 
    public partial class Form1 : Form
    {
        Operaciones operacion = new Operaciones();
        string ipEquipo = "";
        string puertoEquipo = "";
        string puertoPublicacion = "9000";
        string ipPublicacion = "192.168.0.0";
        bool configurado = false;
        bool archivoObtenido = false;
        //--------------------------------------------
        bool prerrequisitos = false;
        string rutaDestinoAPI = "";
        string rutaDescargaAPI = "";
        bool pasoAnteriorCumplido = false;
        string urlWeb = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnIniciaProceso_Click(object sender, EventArgs e)
        {
            btn_ObtenerParametrosConfiguracion.Enabled = false;
            llamaAsincrono();
         }

        private async void llamaAsincrono()
        {
            btnIniciaProceso.Enabled = false;
            btnIniciaProceso.BackColor = Color.DarkSlateGray;
            lblInformacion.Text = "Desplegando...";
            progressBar1.Maximum = 100;
            progressBar1.BackColor = System.Drawing.Color.LimeGreen;
            progressBar1.Value = 0;
            var hecho = await Task.Run(() => Finalizar(archivoObtenido));
            if (hecho == true)
            {
                label2.Text = "¡Interconexión exitosa!";
                label2.Font = new System.Drawing.Font(label2.Font.FontFamily.Name, 16);
                progressBar1.Visible = false;
                btn_ObtenerParametrosConfiguracion.Visible = false;
                btnIniciaProceso.Visible = false;
                Operaciones operaciones = new Operaciones();
                operaciones.reproduceSonido();
                lblInformacion.Text = "";
            }
        }

        #region             Proceso de instalación de la API
        public async Task<bool> instalacionAPI(bool configurado)
        {
            bool instalacionAPI = false;
            bool dockerMontado = false;

            #region Paso 3 Configura y monta y despliega el Docker
            if (configurado == true)
                            {
                                string _rutaGral = System.Configuration.ConfigurationSettings.AppSettings["rutaGral"] != null ? System.Configuration.ConfigurationSettings.AppSettings["rutaGral"] : @"C:\DeclaracionesPDN\API.SESEAP";
                                string rutaDescargaPs1 = _rutaGral + @"\S1_Windows.ps1";
                                dockerMontado = operacion.ejecutaScriptAPI(rutaDescargaPs1, ref ipEquipo, ref puertoEquipo);
                            }
                            else
                            {
                                //progressBar1.Invoke((Action)(() => progressBar1.Value = 0));
                            }
            #endregion Paso 3 Configura y monta y despliega el Docker

            if (dockerMontado==true)
            {
                #region obsoleto 08 Feb 2023 GRD
                //string strHostName = string.Empty;
                //strHostName = Dns.GetHostName();
                //IPAddress[] hostIPs = Dns.GetHostAddresses(strHostName);
                //for (int i = 0; i < hostIPs.Length; i++)
                //{
                //    if(hostIPs[i].ToString().Contains("192.")==true)
                //    ipEquipo=hostIPs[i].ToString();
                //}
                //string url =@"http:\\"+ipPublicacion+@":"+ puertoPublicacion + "/Index.html";
                //despliegaAPI(url);
                //btn_ObtenerParametrosConfiguracion.Visible = false;
                //btnIniciaProceso.Visible = false;
                #endregion obsoleto 08 Feb 2023 GRD
                instalacionAPI = true;
            }
            else
            {
                instalacionAPI = false;
            }
            return instalacionAPI;
        }

        #endregion

        private void btn_ObtenerParametrosConfiguracion_Click(object sender, EventArgs e)
        {
          PreFinaliza();
            if(configurado==false)
            {
                progressBar1.Value = 0;
                lblInformacion.Text = "";
            }
        }

        //Pretermina
        public async Task<bool> PreFinaliza()
        {
            bool ejecutado = false;
            DialogResult dialogBuscaraArchivo = MessageBox.Show("Busque y seleccione el archivo 'parametrosConfiguracion.txt'", "Atención", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if ((dialogBuscaraArchivo == DialogResult.Yes) || (dialogBuscaraArchivo == DialogResult.OK))
            {
                archivoObtenido = obtenParametrosConfiguracion(ref configurado, ref ipEquipo, ref puertoEquipo);
                if (archivoObtenido == true)
                {
                    MessageBox.Show("Presione 'Desplegar API' para finalizar el proceso.", "Todo listo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ejecutado = true;
                    btn_ObtenerParametrosConfiguracion.Enabled = false;
                    btnIniciaProceso.Enabled = true;
                }
                else
                {
                    MessageBox.Show("El archivo solicitado es necesario, reintente por favor o cancele la instalación.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btn_ObtenerParametrosConfiguracion.Enabled = true;
                    btnIniciaProceso.Enabled = false;
                    configurado = false;
                }
            }
            else
            {
                btn_ObtenerParametrosConfiguracion.Enabled = true;
                btnIniciaProceso.Enabled = false;
                ejecutado = false;
            }
            return ejecutado;
        }

        public async Task<bool> Timer(int inicio)
        {
          bool respuesta = false;
          await  Task.Factory.StartNew(() =>
            {
                for (int i = inicio; i <= 100; i++)
                {
                    progressBar1.Invoke((Action)(() => progressBar1.Value = i));
                    Thread.Sleep(120);
                    respuesta = false;
                }
                respuesta = true;
            });
            return respuesta;
        }

        public async Task<bool> Finalizar(bool archivoObtenido)
        {
            bool respuesta = false;
            //Proceso para finalizar instalación
            bool instalacionExitosa = false;
            instalacionExitosa = await Task.Run(() => instalacionAPI(archivoObtenido)); 
            bool timer = await Task.Run(() => Timer(0));
            if (instalacionExitosa == true)
            {
                respuesta = true;
            }
            else
            {
                respuesta = false;
            }
            return respuesta;
        }

        private bool obtenParametrosConfiguracion(ref bool configurado, ref string  ipEquipo, ref string puertoEquipo)
        {
            bool resultado=false;
            bool prerrequisitos = false;
            //Obtiene y configura las rutas de trabajo del Proyecto
            string _rutaGral = System.Configuration.ConfigurationSettings.AppSettings["rutaGral"] != null ? System.Configuration.ConfigurationSettings.AppSettings["rutaGral"] : @"C:\DeclaracionesPDN\API.SESEAP";
            string rutaDescargaPs1 = _rutaGral + @"\S1_Windows.ps1";

            #region Prerrequisitos
            //Obtiene y configura las rutas de trabajo del Proyecto
            bool descargaRealizada = false;
            lblInformacion.Text = "Configurando entorno..";
            //Creando carpetas de trabajo
            operacion.creaCarpetaInstalacionProyecto(_rutaGral);
            //Creando carpetas de trabajo
            #endregion

            lblInformacion.Text = "Bajando archivos fuentes..";
            #region            Obteniendo el script  S1_Windows.ps1 de configuración del Docker
            if (File.Exists(rutaDescargaPs1) == false)
            {
                #region     Obteniendo S1_Windows.ps1 por primera vez
                //Si el archivo NO EXISTE previamente lo obtendremos por 1era vez
                descargaRealizada = operacion.descargaArchivoPs1(rutaDescargaPs1);
                if (descargaRealizada == true)
                {
                    //MessageBox.Show("El script de instalación  fue descargado en la carpeta C:/DeclaracionesPDN/API.SESEAP", "Script descargado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Ocurrío un error obteniendo el archivo Docker, reintente por favor o contacte a soporte tecnico de la PDE Puebla", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                #endregion
            }
            else
            {
                #region El archivo YA EXISTE previamente y lo actualizaremos
                File.Delete(rutaDescargaPs1);
                descargaRealizada = operacion.descargaArchivoPs1(rutaDescargaPs1);
                if (descargaRealizada == true)
                {
                    //Archivo S1_Windows.ps1 descargado
                    //MessageBox.Show("El script de instalación fue descargado y actualizado en la carpeta C:/DeclaracionesPDN/API.SESEAP", "Script actualizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    //Archivo S1_Windows.ps1 NO fue descargado
                    MessageBox.Show("Ocurrío un error descargando el archivo Docker, reintente por favor o contacte a soporte tecnico de la PDE Puebla", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    descargaRealizada = false;
                }
                #endregion
            }
            #endregion Obteniendo el script  S1_Windows.ps1 de configuración del Docker

                #region                     Busca y carga el archivo parametrosConfiguracion.txt
                //Paso 1 Descargando los fuentes de la API SESEAP
                string rutaDestinoAPI = "";
                string rutaDescargaAPI = "";
                prerrequisitos = operacion.descargaArchivoAPISESEAP(ref _rutaGral, ref rutaDestinoAPI,ref urlWeb);
                rutaDescargaAPI = _rutaGral;
                Operaciones operaciones = new Operaciones();
                pasoAnteriorCumplido = false;
                Task tareaDescarga =  LlamaDescargaZIP(prerrequisitos, rutaDestinoAPI, rutaDescargaAPI);
                tareaDescarga.Start();
                do
                {
                    #region        Obtiene el archivo y configura el appsettigs.json        P A R T E     U N O
                    _rutaGral = rutaDestinoAPI;
                    configurado = operacion.configuraParametrosConfiguracion(_rutaGral, ref ipEquipo, ref puertoEquipo);
                    #endregion  Obtiene el archivo y configura el appsettigs.json       P A R T E      U N O
                    puertoPublicacion = puertoEquipo;
                    ipPublicacion = ipEquipo;
                    lblInformacion.Text = "Archivos fuente listos...";
                    resultado = configurado;
                    if(configurado==true)
                        {
                            break;
                        }
                }
                while (tareaDescarga.IsCompleted != true) ;
                #endregion              Busca y carga el archivo parametrosConfiguracion.txt
                pasoAnteriorCumplido = resultado;
                
                return pasoAnteriorCumplido;
        }

        /// <summary>
        /// Dentro de este metodo se hace la llamada asincrónica para descargar el ZIP
        /// descargaOnlineProyectoNET(rutaDescargaAPI, rutaDestinoAPI))
        /// </summary>
        /// <param name="pasoAnterior"></param>
        /// <param name="rutaDescargaAPI"></param>
        /// <param name="rutaDestinoAPI"></param>
        /// <returns></returns>
        public Task LlamaDescargaZIP(bool pasoAnterior,string rutaDescargaAPI, string rutaDestinoAPI)
        {
            bool resultado = false;
            bool prerrequisitos = false;
            return new Task(async () =>
                {
                    if(pasoAnterior==true)
                    {
                        bool _prerrequisitos = await Task.Run(() =>
                            descargaOnlineProyectoNET(rutaDescargaAPI, rutaDestinoAPI)
                        );
                        resultado = true;
                    }
                    else
                    {
                        resultado= false;
                    }
                    pasoAnteriorCumplido=resultado;
                }
            );
        }

        /// <summary>
        /// Metodo que descarga el ZIP y actualiza la barra Progress 
        /// </summary>
        /// <param name="rutaDescargaAPI"></param>
        /// <param name="rutaDestinoAPI"></param>
        /// <returns></returns>
        public async Task<bool> descargaOnlineProyectoNET(string rutaDescargaAPI, string rutaDestinoAPI)
        {
                    bool resultado = false;
                    CheckForIllegalCrossThreadCalls = false;
                    #region descarga Archivos barra progeso en tiempo real
                    if (String.IsNullOrEmpty(urlWeb))
                    {
                        MessageBox.Show("No esta definida la url de descarga del proyecto.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        resultado =false;
                    }
                    else
                    {
                        var BUFFER_SIZE = 9999999;
                        byte[] buffer = new byte[32768];
                        var webRequest = WebRequest.Create(urlWeb);
                        var response = await webRequest.GetResponseAsync();
                        progressBar1.Maximum = (int) response.ContentLength;
                        var list = new List<byte>();
                        var bytes = new byte[BUFFER_SIZE];
                        var stream = response.GetResponseStream();

                        int bytesRead = 0;
                        do
                        {
                            bytesRead = await stream.ReadAsync(bytes, 0, BUFFER_SIZE);
                            list.AddRange(bytes.Take(bytesRead));
                            this.progressBar1.Increment(bytesRead);
                        }
                        while (bytesRead > 0);

                        string filePaths_ = rutaDestinoAPI;
                        using (var fs = File.OpenWrite(filePaths_))
                        {
                            using (var bw = new BinaryWriter(fs))
                            {
                                foreach (var _bytes in list)
                                    bw.Write(_bytes); // Write each byte array to the stream
                            }
                        }
                        Operaciones operaciones = new Operaciones();
                        operaciones.descomprimeProyectoNET(true,rutaDestinoAPI, rutaDescargaAPI);
                        //this.button1.Enabled = true;
                        //MessageBox.Show("File downloaded.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        progressBar1.Value = (int)response.ContentLength;
                        CheckForIllegalCrossThreadCalls = true;
                     }
                    #endregion descarga Archivos barra progeso en tiempo real
                    return resultado;
        }

    }
}
