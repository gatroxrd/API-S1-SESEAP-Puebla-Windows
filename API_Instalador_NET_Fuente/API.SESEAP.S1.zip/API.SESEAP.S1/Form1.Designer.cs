﻿using System.Threading.Tasks;

namespace API.SESEAP.S1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private async Task InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnIniciaProceso = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_ObtenerParametrosConfiguracion = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblInformacion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(14, 446);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(306, 11);
            this.progressBar1.TabIndex = 3;
            // 
            // btnIniciaProceso
            // 
            this.btnIniciaProceso.BackColor = System.Drawing.Color.LimeGreen;
            this.btnIniciaProceso.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIniciaProceso.Enabled = false;
            this.btnIniciaProceso.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciaProceso.ForeColor = System.Drawing.Color.White;
            this.btnIniciaProceso.Location = new System.Drawing.Point(167, 371);
            this.btnIniciaProceso.Margin = new System.Windows.Forms.Padding(4);
            this.btnIniciaProceso.Name = "btnIniciaProceso";
            this.btnIniciaProceso.Size = new System.Drawing.Size(155, 74);
            this.btnIniciaProceso.TabIndex = 4;
            this.btnIniciaProceso.Text = "Desplegar API";
            this.btnIniciaProceso.UseVisualStyleBackColor = false;
            this.btnIniciaProceso.Click += new System.EventHandler(this.btnIniciaProceso_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 460);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "Ver 1.0 (Enero 2023)";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 318);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(306, 49);
            this.label2.TabIndex = 8;
            this.label2.Text = "Instalación y configuración del API de interconexión a la PDE Puebla";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_ObtenerParametrosConfiguracion
            // 
            this.btn_ObtenerParametrosConfiguracion.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn_ObtenerParametrosConfiguracion.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ObtenerParametrosConfiguracion.ForeColor = System.Drawing.Color.Transparent;
            this.btn_ObtenerParametrosConfiguracion.Location = new System.Drawing.Point(11, 371);
            this.btn_ObtenerParametrosConfiguracion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ObtenerParametrosConfiguracion.Name = "btn_ObtenerParametrosConfiguracion";
            this.btn_ObtenerParametrosConfiguracion.Size = new System.Drawing.Size(157, 74);
            this.btn_ObtenerParametrosConfiguracion.TabIndex = 7;
            this.btn_ObtenerParametrosConfiguracion.Tag = " ";
            this.btn_ObtenerParametrosConfiguracion.Text = "Cargar archivo";
            this.btn_ObtenerParametrosConfiguracion.UseVisualStyleBackColor = false;
            this.btn_ObtenerParametrosConfiguracion.Click += new System.EventHandler(this.btn_ObtenerParametrosConfiguracion_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::API.SESEAP.S1.Properties.Resources.logotipo_New_PDE_Impresion;
            this.pictureBox2.Location = new System.Drawing.Point(61, 194);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(202, 116);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::API.SESEAP.S1.Properties.Resources.logo_final_01;
            this.pictureBox1.Location = new System.Drawing.Point(14, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(307, 193);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::API.SESEAP.S1.Properties.Resources.Animacion_Interconexion_Windows_S1;
            this.pictureBox3.Location = new System.Drawing.Point(19, 374);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(295, 70);
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // lblInformacion
            // 
            this.lblInformacion.AutoSize = true;
            this.lblInformacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformacion.Location = new System.Drawing.Point(175, 461);
            this.lblInformacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInformacion.Name = "lblInformacion";
            this.lblInformacion.Size = new System.Drawing.Size(0, 12);
            this.lblInformacion.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(336, 477);
            this.Controls.Add(this.lblInformacion);
            this.Controls.Add(this.btn_ObtenerParametrosConfiguracion);
            this.Controls.Add(this.btnIniciaProceso);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Plataforma Digital Estatal de Puebla";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button btnIniciaProceso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_ObtenerParametrosConfiguracion;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblInformacion;
    }
}

