﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Diagnostics;
using System.IO.Compression;
using System.Management.Instrumentation;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Security.Policy;
using System.Reflection.Emit;
using System.Net.Sockets;
using System.Configuration;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;
using System.Runtime.InteropServices.ComTypes;
using System.Media;

namespace API.SESEAP.S1
{
    internal class Operaciones
    {

        #region             S1_Windows.ps1

        #region             Búsqueda y descarga del script PowerShell posteriormente que instala, configura y despliega el Docker
        /// <summary>
        /// 23Dic 2022
        /// </summary>
        /// Función que descarga el archivo-script  S1_Windows.ps1 para configurar el Docker más el .NET
        /// <param name="ruta">Ubicación donde descargará el archivo</param>
        /// <returns></returns>
        ///GRD
        public bool descargaArchivoPs1(string ruta)
        {
            bool resultado = false;
            string rutaScriptDocker = ConfigurationManager.AppSettings["rutaScriptDocker"];
            using (WebClient wc = new WebClient())
            {
                wc.DownloadFileAsync(
                    new System.Uri(rutaScriptDocker),
                    ruta
                );
                resultado = true;
            }
            return resultado;
        }
        #endregion      Búsqueda y descarga del script PowerShell que posteriormente instala, configura y despliega el Docker

        #region         Script de PowerShell que descarga e instala la imagen .NET en el Docker local y que automonta la API.NET SESEAP
        /// <summary>
        /// 23 Diciembre 2022
        /// GRD
        /// Ejecución del script de PowerShell que descarga e instala la imagen .NET en el Docker local y posteriormente automonta la API.NET SESEAP en el puerto 9000
        /// </summary>
        /// <returns></returns>
        public bool ScriptPs1(string puertoPublicacion)
        {
            string rutaDocker = @"C:\DeclaracionesPDN\API.SESEAP\S1_Windows.ps1";
            #region        Cambiando puerto de publicación
            cambiaPuerto(rutaDocker,puertoPublicacion);
            #endregion

            #region Creando el script Docker
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.Open();
            Pipeline pipeline = runspace.CreatePipeline();
            pipeline.Commands.AddScript(File.ReadAllText(rutaDocker));
            Collection<PSObject> results = pipeline.Invoke();
            runspace.Close();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (PSObject obj in results)
            {
                stringBuilder.AppendLine(obj.ToString());
            }
            Console.WriteLine(stringBuilder.ToString());
            #endregion Creando el script Docker
            return true;
        }
        #endregion  Script de PowerShell que descarga e instala la imagen .NET en el Docker local y que automonta la API.NET SESEAP

        private void cambiaPuerto(string ruta, string puerto)
        {
            string text = File.ReadAllText(ruta);
            text = text.Replace("9000:80",puerto+":80");
            File.WriteAllText(ruta, text);
            //docker run --name dotnet -p 9000:80 -d dotnet
        }

        #region            Ejecución del Script de despliegue de la API al Docker

        /// <summary>
        /// Se invoca al Script que levantará la imagen .NET del Docker y le mosnta la API
        /// </summary>
        /// <param name="rutaScript"></param>
        /// <param name="ipEquipo"></param>
        /// <param name="puertoEquipo"></param>
        /// <returns></returns>
        public bool ejecutaScriptAPI(string rutaScript, ref string ipEquipo, ref string puertoEquipo)
        {
            #region         Levantando el Docker
            bool resultadoScript = ScriptPs1(puertoEquipo);
            #endregion Levantando el Docker
            return resultadoScript;
        }
        #endregion

        #endregion

        #region             ZIP de la API

        #region             Búsqueda y descarga del archivo .ZIP que contiene el proyecto .NET con la API SESEAP
        /// <summary>
        /// 19 Dic 2022
        /// GRD
        /// </summary>
        /// Función que descarga de una ubicación web los archivos fuente (.ZIP) de la API SESEAP y los coloca en una ubicación local proporcionada
        /// <param name="rutaDescargaAPI">Ubicación URL de donde se descargará el .ZIP de la API</param>
        ///  <param name="rutaDestinoAPI">Ubicación dentro del equipo donde se descargará el .ZIP de la API</param>
        /// <returns></returns>
        public bool descargaArchivoAPISESEAP(ref string rutaDescargaAPI, ref string rutaDestinoAPI,ref string urlWeb)
        {
            bool resultado = false;
            bool descargado = false;
            //Revisemos exista la carpea
            rutaDestinoAPI = rutaDescargaAPI + @"\USTPD.S1";
            rutaDescargaAPI = rutaDescargaAPI + @"\USTPD.S1";
            if (Directory.Exists(rutaDestinoAPI) == true)
            {
                //Si existe previmente la eliminaremos
                DeleteDirectory(rutaDestinoAPI);
                Directory.CreateDirectory(rutaDescargaAPI);
            }
            else
            {
                Directory.CreateDirectory(rutaDestinoAPI);
            }
            //-- - - - - - -  --  - - - - - - -  - - - - --  -- -  - - -  - -  - - - -  - - - - -  - - - - -  - - - - - - - - -  - - - - - - - - -  - - - - - - - - - - - - >>
            rutaDescargaAPI = rutaDescargaAPI + @"\PDEPuebla.S1.PDN.zip";
            string rutaProyectoNET = ConfigurationManager.AppSettings["rutaProyectoNET"];
            string url = rutaProyectoNET;
            urlWeb = url;
            #region              Obteniendo el archivo del proyecto .NET  - - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - - - - - ->>
            //var objRequest = System.Net.HttpWebRequest.Create(url);
            //var objResponse = objRequest.GetResponse();
            //byte[] buffer = new byte[32768];
            //using (Stream input = objResponse.GetResponseStream())
            //{
            //    using (FileStream output = new FileStream(rutaDescargaAPI,
            //    FileMode.CreateNew))
            //    {
            //        int bytesRead;

            //        while ((bytesRead = input.Read(buffer, 0, buffer.Length)) > 0)
            //        {
            //            output.Write(buffer, 0, bytesRead);
            //        }
            //    }
            //    descargado = true;
            //    //MessageBox.Show("El proyecto API fue descargado en la carpeta C:/DeclaracionesPDN/API.SESEAP/USTPD.S1", "Archivo ZIP descargado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    descomprimeProyectoNET(descargado, rutaDestinoAPI, rutaDescargaAPI);
            //}
            #endregion    Obteniendo el archivo del proyecto .NET  - - - - - - - - - - -  - - - - - - - - - -  - - - - - - - - - - - - - - ->>
            //- - - - - - - - - - - - - - - - - - - - - - - - - - -  - - -  - - - -  - - -  - - - - - - -  - - - - - -  - - - - - - - - - - - -
            resultado = true;
            return resultado;
        }

        /// <summary>
        /// Método que descomprime el archivo ZIP obtenido previamentedesde una URL externa
        /// Al finalizar este método ya se encontraría el proyeco en el equipo de cómputo
        /// </summary>
        /// <param name="descargado">Resultado de las operaciones realzadas: true = hcho, false = ocurrío algún problema</param>
        /// <param name="rutaDestinoAPI"></param> Ubicación donde se dejara el proyecto descomprimido
        /// <param name="rutaDescargaAPI"></param>Ubicación donde esta el ZIP obtenido 
        /// <returns></returns>
        public bool descomprimeProyectoNET(bool descargado, string rutaDestinoAPI,string rutaDescargaAPI)
        {
            string _aux1 = rutaDestinoAPI;
            string _aux2 = rutaDescargaAPI;
            rutaDescargaAPI = _aux1;
            rutaDestinoAPI = _aux2;
            bool resultado = false;
            if (descargado == true)
            {
                //Procedemos a descomprimir API descargada - - - -  - - - - - - - - -  - - - - - - - - -- - - - -- - - - - - - - - - >>>
                string startPath = rutaDestinoAPI;
                string zipPath = rutaDescargaAPI;
                string extractPath = rutaDestinoAPI;
                ZipFile.ExtractToDirectory(zipPath, extractPath);
                File.Delete(rutaDescargaAPI);
                //MessageBox.Show("El archivo ZIP de la API fue descomprimido correctamente en la carpeta C:/DeclaracionesPDN/API.SESEAP/USTPD.S1", "Archivo ZIP descomprimido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                resultado = true;
                //Procedemos a descomprimir API descargada - - - -  - - - - - - - - -  - - - - - - - - -- - - - -- - - - - - - - - - >>>
            }
            return resultado;
        }

        #endregion       Búsqueda y descarga del archivo .ZIP que contiene el proyecto .NET con la API SESEAP

        #endregion

        #region                 Configuración del AppSettings.json

        /// <summary>
        /// Proceso de configuración del archivo AppSettings.com
        /// con los valores extraidos del archivo parametrosConfiguracion.txt
        /// Se solocitará la ubicación del archivo parametrosConfiguracion.txt
        /// </summary>
        /// <param name="rutaParametrosConfiguracion">Ubicación del archivo parametrosConfiguracion.txt</param>
        /// <param name="ipEquipo">IP del equipo donde se esta instalando la API desde mongoHostname</param>
        /// <param name="puertoEquipo">Puerto donde se montará la API desde deploymentPort</param>
        /// <returns></returns>
        public bool configuraParametrosConfiguracion(string rutaParametrosConfiguracion, ref string ipEquipo, ref string puertoEquipo)
        {
            bool configuracionRealizada = false;
            Dictionary<string, string> valoresDelArchivoFuente = new Dictionary<string, string>();
            rutaParametrosConfiguracion = rutaParametrosConfiguracion + @"\parametrosConfiguracion.txt";
            string rutaAppSettingsJson = @"C:\DeclaracionesPDN\API.SESEAP\USTPD.S1\appsettings.json";
            if (File.Exists(rutaParametrosConfiguracion) == false)
            {
                valoresDelArchivoFuente = localizaParametrosConfiguracion(ref ipEquipo, ref puertoEquipo);
            }
            else
            {
                valoresDelArchivoFuente = extraeParametrosConfiguracion(rutaAppSettingsJson, ref ipEquipo, ref puertoEquipo);
            }
            //- - - - - - -- - - - - - - - -  - - - -  - - - -  - - - - - - - - - - - - - - - - - - - -- - - - - - - -
            if(valoresDelArchivoFuente!=null)
            {
                //Obteniendo valores de parametrosConfiguacion.txt - - - - - - - - - - - - 
                bool parametrosValidos = validaParametros(valoresDelArchivoFuente);
                if(parametrosValidos==true)
                {
                    foreach (var valor in valoresDelArchivoFuente)
                    {
                        string text = File.ReadAllText(rutaAppSettingsJson);
                        text = text.Replace(valor.Key, valor.Value);// "some text", "new value");
                        File.WriteAllText(rutaAppSettingsJson, text);
                        configuracionRealizada = true;
                        if(valor.Key.ToString().Equals("deploymentPort")==true)
                        {
                            puertoEquipo= valor.Value.ToString();
                        }
                        if (valor.Key.ToString().Equals("mongoHostname") == true)
                        {
                            ipEquipo = valor.Value.ToString();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("La información contenida en el archivo 'parametrosConfiguracion.txt' no cumple con el estandar esperado o faltan algunos valores, verifíque por favor.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    configuracionRealizada = false;
                }
                //- - - - - - -- - - - - - - - -  - - - -  - - - -  - - - - - - - - - - - - - - - - - - - -- - - - - - - -
            }
            else
            {
                MessageBox.Show("No selecciono el archivo 'parametrosConfiguracion.txt', la instalación se cancelará.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                configuracionRealizada = false;
            }
            return configuracionRealizada;
        }

        private bool validaParametros(Dictionary<string, string> valoresDelArchivoFuente)
        {
            List<string> list = new List<string>();
            bool esValido = true;
            #region           
            list.Add("apiName");
            list.Add("clientId");
            list.Add("clientScopeRead");
            list.Add("clientScopeWrite");
            list.Add("clientDescription");
            list.Add("mongoUsername");
            list.Add("mongoPassword");
            list.Add("mongoHostname");
            list.Add("mongoPort");
            list.Add("mongoDatabase");
            list.Add("deploymentPort");
            #endregion

            if(valoresDelArchivoFuente!=null)
            {
                //Si trae información
                if (valoresDelArchivoFuente.Count()==list.Count())
                {
                    var camposComunes = list.Intersect(valoresDelArchivoFuente.Keys);
                    if(camposComunes.Count()== list.Count())
                    {
                        //Todos los campos requeridos coindiciden, ahora checamos si todos los campos
                        //traen valor para configurar
                        foreach(var item in valoresDelArchivoFuente.Values)
                        {
                            if(item.Length<=0)
                            {
                                //Un valor viene vacio, esto NO es válido
                                esValido= false;
                                break;
                            }
                        }
                    }
                    else
                    {
                        //Los valores "nombres"  los campos no coinciden con los esperados
                        esValido= false;
                    }
                }
                else
                {
                    //La lista no trae todos los campos
                    esValido = false;
                }
            }
            else
            {
                //No información que analizar
                esValido= false;
            }

            return esValido;
        }

        /// <summary>
        /// Localiza el archivo parametrosConfiguracion.txt en el equipo local y 
        /// extrae la lista de valores ahi contenidos para posteriormente 
        /// configurar el AppSettings.json
        /// </summary>
        /// <param name="ipEquipo">IP del equipo donde se esta instalando la API</param>
        /// <param name="puertoEquipo">Puerto donde se montará la API</param>
        /// <returns>Arreglo de valores</returns>
        public Dictionary<string, string> localizaParametrosConfiguracion(ref string ipEquipo, ref string puertoEquipo)
        {
            Dictionary<string, string> llavesValores = new Dictionary<string, string>();
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.DefaultExt = ".txt";
            ofd.Title = "Cargar archivo: parametrosConfiguracion.txt";
            ofd.Filter = "All Files(*.*) | *.*";
            DialogResult dr = ofd.ShowDialog();
            try
            {
                if(ofd.FileName.Contains("parametrosConfiguracion.txt")==true)
                {
                    StreamReader sr = new StreamReader(ofd.FileName);
                    string[] datos = new string[0];
                    if (dr == DialogResult.OK)
                    {
                        string archivo = sr.ReadToEnd();
                        sr.Close();
                        using (var streamReader = File.OpenText(ofd.FileName)) //fileName))
                        {
                            var lines = streamReader.ReadToEnd().Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                            foreach (var line in lines)
                            {
                                datos = line.Split(Convert.ToChar("="));
                                string campo = datos[0].ToString();
                                string valor = datos[1].ToString();
                                llavesValores.Add(campo, valor);
                                if (campo.Equals("mongoHostName") == true)
                                {
                                    ipEquipo = valor;
                                }
                                else
                                {
                                    if (campo.Equals("mongoPort") == true)
                                    {
                                        puertoEquipo = valor;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No selecciono el archivo 'parametrosConfiguracion.txt', verifíque por favor.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    llavesValores = null;
                }
            }
            catch(Exception error)
            {
                return null;
            }
            return llavesValores;
        }

        /// <summary>
        ///     Extracción de los valores del archivo parametrosConfiguracion.txt ya ubicado localmente
        ///     con el que posteriormente configuramos el AppSettings.json
        /// </summary>
        /// <param name="rutaParametrosConfiguracion"></param>
        /// <param name="ipEquipo">IP del equipo donde se esta instalando la API</param>
        /// <param name="puertoEquipo">Puerto donde se montará la API</param>
        /// <returns>Arreglo de valores</returns>
        public Dictionary<string, string> extraeParametrosConfiguracion(string rutaParametrosConfiguracion, ref string ipEquipo, ref string puertoEquipo)
        {
            Dictionary<string, string> llavesValores = new Dictionary<string, string>();
            StreamReader sr = new StreamReader(rutaParametrosConfiguracion);
            string[] datos = new string[0];
            string archivo = sr.ReadToEnd();
            sr.Close();
            using (var streamReader = File.OpenText(rutaParametrosConfiguracion))
            {
                var lines = streamReader.ReadToEnd().Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                foreach (var line in lines)
                {
                    datos = line.Split(Convert.ToChar("="));
                    string campo = datos[0].ToString();
                    string valor = datos[1].ToString();
                    llavesValores.Add(campo, valor);
                    if (campo.Equals("hostName") == true)
                    {
                        ipEquipo = valor;
                    }
                    else
                    {
                        if (campo.Equals("port") == true)
                        {
                            puertoEquipo = valor;
                        }
                    }
                }
            }
            return llavesValores;
        }

        #endregion

        #region             Complementos
        public static void DeleteDirectory(string path) 
        { 
            foreach (string directory in Directory.GetDirectories(path))
              {
                 DeleteDirectory(directory); 
               }
            try
            { 
               Directory.Delete(path, true); 
            }
            catch (IOException) 
            {
                Directory.Delete(path, true);
            } 
            catch (UnauthorizedAccessException)
            {
                Directory.Delete(path, true);
            }
        }
        public static void despliegaAPI(string url)
        {
            var uri = url;
            var psi = new System.Diagnostics.ProcessStartInfo();
            psi.UseShellExecute = true;
            psi.FileName = uri;
            System.Diagnostics.Process.Start(psi);
        }
        public void creaCarpetaInstalacionProyecto(string _rutaGral)
        {
            //- - - - - - - - - - - - - - - - - - -- - - - - - -  -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -- - - - - - - - - -  - - - - -  - - - - - - - - - - - - - - - - - - - - - -
            //Existe la carpeta Base
            if (Directory.Exists(_rutaGral) == true)
            {
                //Si existe previamente la carpeta la eliminaremos por completo
                //para realizar la actualización TOTAL
                DeleteDirectory(_rutaGral);
                //Se re-crea la carpeta Base Gral
                Directory.CreateDirectory(_rutaGral);
            }
            else
            {
                //Se re-crea la carpeta Base Gral
                Directory.CreateDirectory(_rutaGral);
            }
            //- - - - - - - - - - - - - - - - - - -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
        }
        public void reproduceSonido()
        {
            try
            {
                //Especificar el archivo de audio a reproducir
                string fileName = @"../../Ensoniq-ESQ-1-Bell-C5.wav";
                // Create a new instance of SoundPlayer
                System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                player.SoundLocation = fileName;
                player.Load();
                player.Play();
            }
            catch(Exception ex)
            {
                string error = ex.Message;
            }
        }

    #endregion

    }
}
